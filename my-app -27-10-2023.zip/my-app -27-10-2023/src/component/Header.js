import React from 'react'
import { Link } from 'react-router-dom'
import  '../App.css';
export default function Header() {
  {/* style */}
  const style = {
    minHeight: '40px',
    padding:'8px 20px'
  };
  return (
    <>
    {/* Header Structure */}
    <div className='d-flex justify-content-between customHeader bg-dark text-white' style={style}>
    <div >Header</div>
    <div>
      {/* pages Link */}
    <Link to={"/"}>Home</Link>
    <Link to={"/about"}>About</Link>
    </div>
    
    </div>
    
    </>
   
  )
}
