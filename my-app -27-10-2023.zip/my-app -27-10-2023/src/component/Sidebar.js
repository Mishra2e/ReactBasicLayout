import React from 'react'

export default function Sidebar(props) {
    {/* style */}
  const style={
    minHeight:'85vh'
  }
  return (
    <>
    <div style={style} className='bg-dark text-white my-2'>
        {/* sidebar txt through props */}
<p className='mb-0 pt-5 text-center'>{props.title}</p>
    </div>
    </>
  )
}
