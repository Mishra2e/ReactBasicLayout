import React from 'react'

export default function Footer() {
    {/* Style */}
  const style={
    minHeight:'40px'
  }
  return (
    <>
    <footer className='bg-dark text-white text-center' style={style}>
        {/* Copyright txt */}
      <p className='mb-0 pt-2'>2023 &copy; copyright</p>
    </footer>
    </>
  )
}
