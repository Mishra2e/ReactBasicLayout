import React from 'react'

export default function About() {
    {/* Style */}
  const style ={
minHeight:'85vh'
  }
  return (
    <>
    <div style={style} className='bg-light text-center my-2'>
        {/* About Text */}
    <p className='mb-0 pt-5 text-center'>About</p>
    </div>
    </>
  )
}


