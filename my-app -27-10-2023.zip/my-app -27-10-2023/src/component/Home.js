import React ,{useState} from 'react'

export default function Home() {
    {/* style */}
  const style={
    minHeight:'85vh'
  }
  {/* intial count value setting at 0 */}
  const [count, setCount] = useState(0);
  {/* increment Function */}
  const increment = () => {
    setCount(count + 1);
  };

  return (
    <>
    <div style={style} className='bg-light text-center my-2'>
      {/* Home Text */}
    <p className='mb-0 pt-5 text-center'>Home</p>
     {/* intial count value */}
    <p className='pt-4'>Count: {count}</p>
    {/* Btn to incress count value */}
      <button onClick={increment} className='btn btn-success'>Increment</button>

    </div>
    </>
  )
}
