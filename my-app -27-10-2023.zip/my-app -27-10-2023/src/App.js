import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './component/Home';
import About from './component/About';
import Header from './component/Header';
import Footer from './component/Footer';
import Sidebar from './component/Sidebar';
import './App.css'
function App() {
  return (
   
    <div className='container-fluid'>
       {/* layout row */}
      <div className='row'>
         {/* Router as wrapper */}
        <Router>
           {/* Setting Header Coponent on top of all page */}
          <div className='col-md-12 px-0'>
            <Header></Header>
          </div>
          {/* Setting Sidebar Coponent on left side of all page */}
          <div className='col-md-2'>
            <Sidebar title="aside"></Sidebar>
          </div>
          <div className='col-md-10 '>
            {/* Setting routing so that on right side content changes on click of home or about */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="*" element={<p>page not found</p>} />
          </Routes>
          </div>
           {/* Setting footer on bottom of the page */}
          <div className='col-md-12 px-0'>
            <Footer></Footer>
          </div>
        </Router>
      </div>
    </div>
  );
}

export default App;
